"use strict";

document.getElementById("username-text").innerHTML=localStorage.getItem("email");
